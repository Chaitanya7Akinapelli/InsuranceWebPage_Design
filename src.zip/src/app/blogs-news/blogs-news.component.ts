import { Component } from '@angular/core';

@Component({
  selector: 'app-blogs-news',
  standalone: true,
  imports: [],
  templateUrl: './blogs-news.component.html',
  styleUrl: './blogs-news.component.css'
})
export class BlogsNewsComponent {

}
