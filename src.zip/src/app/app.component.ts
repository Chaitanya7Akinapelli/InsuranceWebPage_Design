// app.component.ts
import { Component } from '@angular/core';
import { HeaderComponent } from './header/header/header.component';
import { HeroComponent } from './hero/hero/hero.component';
import { ServicesComponent } from './services/services/services.component';
import { CallToActionComponent } from './call-to-action/call-to-action/call-to-action.component';
import { FooterComponent } from './footer/footer.component';
import { BlogsNewsComponent } from './blogs-news/blogs-news.component';
import { ExpertComponent } from './expert/expert.component';
@Component({
  selector: 'app-root',
  standalone: true, 
  imports: [HeroComponent, HeaderComponent, ServicesComponent,CallToActionComponent,FooterComponent,BlogsNewsComponent,ExpertComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Your Angular App';
}
