import { Component } from '@angular/core';

@Component({
  selector: 'app-expert',
  standalone: true,
  imports: [],
  templateUrl: './expert.component.html',
  styleUrl: './expert.component.css'
})
export class ExpertComponent {

}
