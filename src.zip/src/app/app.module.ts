import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header/header.component';
import { HeroComponent } from './hero/hero/hero.component';
import { ServicesComponent } from './services/services/services.component';
import { CallToActionComponent } from './call-to-action/call-to-action/call-to-action.component';
import { FooterComponent } from './footer/footer.component';
import { BlogsNewsComponent } from './blogs-news/blogs-news.component';
import { ExpertComponent } from './expert/expert.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HeroComponent,
    ServicesComponent,
    CallToActionComponent,
    FooterComponent,
    BlogsNewsComponent,
    ExpertComponent
  ],
  imports: [BrowserModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
